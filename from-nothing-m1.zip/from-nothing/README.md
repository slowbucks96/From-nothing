# FROM NOTHING

Top-down life-sim RPG about rising from poverty to financial independence. Phaser 3 + TypeScript + Vite. Built for iPhone Safari (portrait, touch).
Status: **v0.1 Milestone 1** — see `CHECKLIST.md` for exactly what exists.

## Run it on your computer
Requires Node 18+.
```
npm install
npm run dev
```
Vite prints a `Local:` and a `Network:` URL.

## Play on your iPhone while developing (same Wi-Fi)
1. Run `npm run dev` on the computer.
2. On the iPhone, open Safari and go to the **Network** URL (looks like `http://192.168.1.23:5173`).
3. Tap Share → **Add to Home Screen** for a full-screen app icon.

## Play on your iPhone with NO computer (recommended)
Host it once; the game then lives at a normal web address.

**Option A — GitHub Pages (auto-updates every time you push):**
1. Create a GitHub repo, upload this project (the `.github/workflows/deploy.yml` file is included).
2. Repo → Settings → Pages → Source: **GitHub Actions**.
3. Push to `main`. After ~1–2 minutes your game is at `https://YOUR-NAME.github.io/REPO-NAME/`.
4. Open that URL in iPhone Safari → Share → **Add to Home Screen**.
(Pages on a *private* repo needs a paid GitHub plan; public repos are free.)

**Option B — Netlify / Cloudflare Pages:** connect the repo, build command `npm run build`, publish directory `dist`.
Or run `npm run build` once and drag the `dist` folder onto netlify.com/drop.

Notes
- Saves live in the browser's localStorage **per web address**. The Home Screen app and Safari tab keep separate saves, and each new URL starts fresh.
- Code changes need a rebuild/redeploy. With Option A you can edit files in GitHub's web editor on your phone and it redeploys itself.
- Verify the code compiles any time with `npm run typecheck`.

## Controls
Touch: joystick bottom-left (8 directions), context button bottom-right when near a door.
Desktop testing: WASD / arrow keys.

## Project layout
See `docs/ARCHITECTURE.md`. Art rules and how to swap in real art: `docs/ART_SPEC.md`.
