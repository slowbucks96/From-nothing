import { bus } from '../core/events';
import { formatClock } from '../core/clock';
import { game } from '../core/state';
import { Joystick } from './controls';
import { el, uiRoot } from './dom';

export interface HudOptions { onSave: () => void; onNewGame: () => void }

export function mountHud(opts: HudOptions) {
  const wrap = el('div', 'hud');
  wrap.append(el('div', 'vignette'));

  const top = el('div', 'hud-top');
  const cash = el('div', 'pill cash', `$${game.money}`);
  const clock = el('div', 'pill clock', formatClock(game.time));
  const menuBtn = el('button', 'pill btn', '☰');
  top.append(cash, clock, menuBtn);

  const toast = el('div', 'toast');
  const prompt = el('button', 'prompt');
  const joy = new Joystick(wrap);

  const menu = el('div', 'modal');
  const card = el('div', 'card');
  card.append(el('h2', '', 'Paused'));
  const mk = (label: string, fn: () => void, cls = 'btn big') => { const b = el('button', cls, label); b.onclick = fn; card.append(b); };
  mk('Resume', () => menu.classList.remove('show'));
  mk('Save game', () => { opts.onSave(); menu.classList.remove('show'); showToast('Game saved'); });
  mk('New game', () => {
    if (confirm('Start a new game? Your current save will be erased.')) opts.onNewGame();
  }, 'btn big danger');
  menu.append(card);
  menuBtn.onclick = () => menu.classList.add('show');

  wrap.append(top, toast, prompt, menu);
  uiRoot().append(wrap);

  let toastTimer = 0;
  function showToast(msg: string) {
    toast.textContent = msg;
    toast.classList.add('show');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove('show'), 3800);
  }

  const offs = [
    bus.on('money', (m) => { cash.textContent = `$${m}`; }),
    bus.on('clock', (t) => { clock.textContent = formatClock(t); }),
    bus.on('toast', showToast),
    bus.on('prompt', (p) => {
      if (!p) { prompt.classList.remove('show'); prompt.onclick = null; return; }
      prompt.textContent = p.label;
      prompt.onclick = p.run;
      prompt.classList.add('show');
    }),
  ];

  return {
    joystick: joy,
    destroy() { offs.forEach((o) => o()); joy.destroy(); wrap.remove(); window.clearTimeout(toastTimer); },
  };
}
