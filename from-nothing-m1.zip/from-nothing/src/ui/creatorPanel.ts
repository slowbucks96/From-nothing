import { Appearance } from '../core/types';
import { CLOTH_COLORS, HAIR_COLORS, OPTIONS, SKIN_TONES } from '../data/appearance';
import { el, uiRoot } from './dom';

type Ctl =
  | { kind: 'options'; key: keyof Appearance; label: string; list: string[] }
  | { kind: 'swatch'; key: keyof Appearance; label: string; colors: number[] };

const TABS: { name: string; identity?: boolean; controls: Ctl[] }[] = [
  { name: 'Body', identity: true, controls: [
    { kind: 'swatch', key: 'skin', label: 'Skin tone', colors: SKIN_TONES },
    { kind: 'options', key: 'body', label: 'Build', list: OPTIONS.body },
  ] },
  { name: 'Hair', controls: [
    { kind: 'options', key: 'hairStyle', label: 'Style', list: OPTIONS.hairStyle },
    { kind: 'swatch', key: 'hairColor', label: 'Color', colors: HAIR_COLORS },
    { kind: 'options', key: 'facial', label: 'Facial hair', list: OPTIONS.facial },
  ] },
  { name: 'Face', controls: [{ kind: 'options', key: 'face', label: 'Expression', list: OPTIONS.face }] },
  { name: 'Clothes', controls: [
    { kind: 'options', key: 'shirt', label: 'Shirt', list: OPTIONS.shirt },
    { kind: 'swatch', key: 'shirtColor', label: 'Shirt color', colors: CLOTH_COLORS },
    { kind: 'options', key: 'pants', label: 'Pants', list: OPTIONS.pants },
    { kind: 'swatch', key: 'pantsColor', label: 'Pants color', colors: CLOTH_COLORS },
    { kind: 'options', key: 'shoes', label: 'Shoes', list: OPTIONS.shoes },
    { kind: 'swatch', key: 'shoeColor', label: 'Shoe color', colors: CLOTH_COLORS },
  ] },
  { name: 'Extras', controls: [
    { kind: 'options', key: 'accessory', label: 'Accessory', list: OPTIONS.accessory },
    { kind: 'options', key: 'backpack', label: 'Backpack', list: OPTIONS.backpack },
    { kind: 'swatch', key: 'backpackColor', label: 'Pack color', colors: CLOTH_COLORS },
  ] },
];

export interface CreatorHandlers {
  onChange: (a: Appearance) => void;
  onStart: (a: Appearance) => void;
  onWalk: (on: boolean) => void;
  onTurn: () => void;
}

const hex = (c: number) => '#' + c.toString(16).padStart(6, '0');

export function mountCreator(look: Appearance, h: CreatorHandlers) {
  const root = el('div', 'creator');
  const tools = el('div', 'cr-tools');
  const turn = el('button', 'pill btn', '↻ Turn');
  const walk = el('button', 'pill btn', '▶ Walk');
  let walking = false;
  turn.onclick = () => h.onTurn();
  walk.onclick = () => { walking = !walking; walk.textContent = walking ? '⏸ Stop' : '▶ Walk'; h.onWalk(walking); };
  tools.append(turn, walk);

  const panel = el('div', 'cr-panel');
  const tabs = el('div', 'cr-tabs');
  const body = el('div', 'cr-body');
  const foot = el('div', 'cr-foot');
  const note = el('div', 'cr-note', 'Starter clothes and backpack are free.');
  const go = el('button', 'btn big go', 'Start Life');
  foot.append(note, go);
  panel.append(tabs, body, foot);
  root.append(tools, panel);
  uiRoot().append(root);

  const set = (key: keyof Appearance, v: number) => {
    (look as unknown as Record<string, number | string>)[key] = v;
    h.onChange(look);
  };

  function render(i: number) {
    tabs.innerHTML = '';
    TABS.forEach((t, n) => {
      const b = el('button', 'tab' + (n === i ? ' on' : ''), t.name);
      b.onclick = () => render(n);
      tabs.append(b);
    });
    body.innerHTML = '';
    const tab = TABS[i];
    if (tab.identity) {
      const r1 = el('div', 'row');
      r1.append(el('label', '', 'Name'));
      const input = el('input', 'name-input');
      input.type = 'text'; input.maxLength = 14; input.placeholder = 'Your name'; input.value = look.name;
      input.oninput = () => { look.name = input.value; };
      r1.append(input);
      const r2 = el('div', 'row');
      const ageLbl = el('label', '', `Age: ${look.age}`);
      const age = el('input', 'age-input');
      age.type = 'range'; age.min = '18'; age.max = '25'; age.step = '1'; age.value = String(look.age);
      age.oninput = () => { look.age = Number(age.value); ageLbl.textContent = `Age: ${look.age}`; };
      r2.append(ageLbl, age);
      body.append(r1, r2);
    }
    for (const c of tab.controls) {
      const row = el('div', 'row');
      row.append(el('label', '', c.label));
      if (c.kind === 'options') {
        const stepper = el('div', 'stepper');
        const prev = el('button', 'btn sm', '◀');
        const next = el('button', 'btn sm', '▶');
        const val = el('span', 'val', c.list[look[c.key] as number]);
        const bump = (d: number) => {
          const n = (((look[c.key] as number) + d) % c.list.length + c.list.length) % c.list.length;
          set(c.key, n); val.textContent = c.list[n];
        };
        prev.onclick = () => bump(-1); next.onclick = () => bump(1);
        stepper.append(prev, val, next);
        row.append(stepper);
      } else {
        const sw = el('div', 'swatches');
        c.colors.forEach((col, n) => {
          const s = el('button', 'swatch' + (look[c.key] === n ? ' on' : ''));
          s.style.background = hex(col);
          s.onclick = () => { set(c.key, n); sw.querySelectorAll('.swatch').forEach((x, k) => x.classList.toggle('on', k === n)); };
          sw.append(s);
        });
        row.append(sw);
      }
      body.append(row);
    }
  }
  render(0);

  go.onclick = () => { look.name = look.name.trim() || 'Alex'; h.onStart(look); };

  return { destroy() { root.remove(); } };
}
