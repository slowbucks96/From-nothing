import { el } from './dom';

/** Touch joystick (DOM, pointer events). Output is snapped to 8 directions per the design spec. */
export class Joystick {
  vec = { x: 0, y: 0 };
  private root: HTMLElement;
  private base: HTMLElement;
  private knob: HTMLElement;
  private id: number | null = null;
  private cx = 0;
  private cy = 0;
  private readonly R = 52;

  constructor(parent: HTMLElement) {
    this.root = el('div', 'joy');
    this.base = el('div', 'joy-base');
    this.knob = el('div', 'joy-knob');
    this.base.append(this.knob);
    this.root.append(this.base);
    parent.append(this.root);

    this.root.addEventListener('pointerdown', (e) => {
      if (this.id !== null) return;
      this.id = e.pointerId;
      this.root.setPointerCapture(e.pointerId);
      const r = this.base.getBoundingClientRect();
      this.cx = r.left + r.width / 2;
      this.cy = r.top + r.height / 2;
      this.move(e);
      e.preventDefault();
    });
    this.root.addEventListener('pointermove', (e) => { if (e.pointerId === this.id) this.move(e); });
    const end = (e: PointerEvent) => {
      if (e.pointerId !== this.id) return;
      this.id = null;
      this.vec = { x: 0, y: 0 };
      this.knob.style.transform = 'translate(0px, 0px)';
    };
    this.root.addEventListener('pointerup', end);
    this.root.addEventListener('pointercancel', end);
  }

  private move(e: PointerEvent) {
    let dx = e.clientX - this.cx, dy = e.clientY - this.cy;
    const len = Math.hypot(dx, dy);
    const k = len > this.R ? this.R / len : 1;
    dx *= k; dy *= k;
    this.knob.style.transform = `translate(${dx}px, ${dy}px)`;
    const mag = Math.hypot(dx, dy) / this.R;
    if (mag < 0.2) { this.vec = { x: 0, y: 0 }; return; }
    const a = Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) * (Math.PI / 4);
    this.vec = { x: Math.cos(a), y: Math.sin(a) };
  }

  destroy() { this.root.remove(); }
}
