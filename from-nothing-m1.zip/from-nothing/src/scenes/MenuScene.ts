import Phaser from 'phaser';
import { hasSave, clearSave } from '../core/save';
import { continueGame } from '../core/session';
import { el, uiRoot } from '../ui/dom';

export class MenuScene extends Phaser.Scene {
  private root?: HTMLElement;
  constructor() { super('Menu'); }

  create() {
    this.cameras.main.setBackgroundColor('#2a2440');
    const root = el('div', 'menu');
    root.append(el('div', 'logo', 'FROM\nNOTHING'));
    root.append(el('div', 'tag', 'Rise in Westhaven.'));
    const btns = el('div', 'menu-btns');
    if (hasSave()) {
      const c = el('button', 'btn big go', 'Continue');
      c.onclick = () => { if (continueGame()) this.scene.start('World'); };
      btns.append(c);
    }
    const n = el('button', 'btn big', 'New Game');
    n.onclick = () => {
      if (hasSave() && !confirm('Start a new game? Your current save will be erased.')) return;
      clearSave();
      this.scene.start('Creator');
    };
    btns.append(n);
    root.append(btns, el('div', 'ver', 'v0.1 · Milestone 1 · Eastside'));
    uiRoot().append(root);
    this.root = root;
    this.events.once('shutdown', () => this.root?.remove());
  }
}
