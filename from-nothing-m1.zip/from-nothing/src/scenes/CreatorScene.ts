import Phaser from 'phaser';
import { CharacterRig, Facing } from '../entities/CharacterRig';
import { DEFAULT_APPEARANCE } from '../data/appearance';
import { Appearance } from '../core/types';
import { mountCreator } from '../ui/creatorPanel';
import { startNewGame } from '../core/session';

const TURNS: { f: Facing; flip: number }[] = [
  { f: 'down', flip: 1 }, { f: 'side', flip: 1 }, { f: 'up', flip: 1 }, { f: 'side', flip: -1 },
];

export class CreatorScene extends Phaser.Scene {
  private rig!: CharacterRig;
  private look!: Appearance;
  private bg!: Phaser.GameObjects.Graphics;
  private panel?: { destroy(): void };
  private walking = false;
  private turn = 0;
  constructor() { super('Creator'); }

  create() {
    this.look = { ...DEFAULT_APPEARANCE };
    this.bg = this.add.graphics();
    this.rig = new CharacterRig(this, 0, 0, this.look, 1);
    this.layout();
    this.scale.on('resize', this.layout, this);

    this.panel = mountCreator(this.look, {
      onChange: (a) => this.rig.setLook(a),
      onWalk: (on) => { this.walking = on; },
      onTurn: () => { this.turn = (this.turn + 1) % 4; const t = TURNS[this.turn]; this.rig.face(t.f, t.flip); },
      onStart: (a) => { startNewGame(a); this.scene.start('World'); },
    });
    this.events.once('shutdown', () => { this.scale.off('resize', this.layout, this); this.panel?.destroy(); });
  }

  private layout() {
    const w = this.scale.width, h = this.scale.height;
    const previewH = h * 0.5;
    this.bg.clear();
    this.bg.fillGradientStyle(0xf7c27c, 0xf7c27c, 0xd9703c, 0xd9703c, 1);
    this.bg.fillRect(0, 0, w, h);
    // brick wall hint
    this.bg.fillStyle(0x000000, 0.06);
    for (let y = 0; y < previewH; y += 22) for (let x = (y / 22) % 2 ? 0 : -30; x < w; x += 60) this.bg.fillRect(x + 2, y + 2, 56, 18);
    const s = Math.min((previewH * 0.74) / 88, (w * 0.7) / 70);
    const feetY = previewH * 0.86;
    this.bg.fillStyle(0x2b1b2f, 0.25);
    this.bg.fillEllipse(w / 2, feetY, 78 * s, 20 * s);
    this.rig.setPosition(w / 2, feetY);
    this.rig.setBaseScale(s);
  }

  update(_t: number, delta: number) {
    const dt = delta / 1000;
    let vx = 0, vy = 0;
    if (this.walking) {
      const t = TURNS[this.turn];
      if (t.f === 'down') vy = 1; else if (t.f === 'up') vy = -1; else vx = t.flip;
    }
    this.rig.tick(dt, vx, vy);
  }
}
