import Phaser from 'phaser';
import { game } from '../core/state';
import { bus } from '../core/events';
import { save, clearSave } from '../core/save';
import { GAME_MIN_PER_SEC, darkness, tintFor } from '../core/clock';
import { CharacterRig } from '../entities/CharacterRig';
import { Wanderer } from '../entities/Wanderer';
import { buildEastside, WorldDef } from '../maps/eastside';
import { mountHud } from '../ui/hud';
import { WANDERER_LOOKS } from '../data/appearance';

const STEP = 1 / 60; // fixed simulation timestep
const SPEED = 108;
const FEET_W = 18, FEET_H = 10;

export class WorldScene extends Phaser.Scene {
  private world!: WorldDef;
  private player!: CharacterRig;
  private hud!: ReturnType<typeof mountHud>;
  private overlay!: Phaser.GameObjects.Rectangle;
  private glows: { o: Phaser.GameObjects.Shape; max: number }[] = [];
  private wanderers: Wanderer[] = [];
  private cursors?: Phaser.Types.Input.Keyboard.CursorKeys;
  private wasd?: Record<string, Phaser.Input.Keyboard.Key>;
  private acc = 0;
  private uiT = 0;
  private saveT = 0;
  private pvx = 0;
  private pvy = 0;
  private promptId: string | null = null;
  private skipSave = false;
  private onHide = () => { if (document.visibilityState === 'hidden') { this.sync(); save(); } };

  constructor() { super('World'); }

  create() {
    const w = (this.world = buildEastside(this));

    this.overlay = this.add.rectangle(w.width / 2, w.height / 2, w.width + 1400, w.height + 1400, 0xffffff)
      .setDepth(9000).setBlendMode(Phaser.BlendModes.MULTIPLY);
    for (const r of w.lights) {
      const o = this.add.rectangle(r.x + r.w / 2, r.y + r.h / 2, r.w, r.h, 0xffd27a).setDepth(9100).setAlpha(0).setBlendMode(Phaser.BlendModes.ADD);
      this.glows.push({ o, max: 0.8 });
    }
    for (const g of w.glows) {
      const o = this.add.ellipse(g.x, g.y, g.r * 2, g.r * 2, 0xffe3a0).setDepth(9100).setAlpha(0).setBlendMode(Phaser.BlendModes.ADD);
      this.glows.push({ o, max: 0.3 });
    }

    w.wanderZones.forEach((z, i) => this.wanderers.push(new Wanderer(this, z, WANDERER_LOOKS[i % WANDERER_LOOKS.length])));

    this.player = new CharacterRig(this, game.pos.x, game.pos.y, game.appearance, 1);
    const cam = this.cameras.main;
    cam.setBounds(0, 0, w.width, w.height);
    cam.startFollow(this.player, true, 0.12, 0.12);
    this.applyZoom();
    this.scale.on('resize', this.applyZoom, this);

    if (this.input.keyboard) {
      this.cursors = this.input.keyboard.createCursorKeys();
      this.wasd = this.input.keyboard.addKeys('W,A,S,D') as Record<string, Phaser.Input.Keyboard.Key>;
    }

    this.hud = mountHud({
      onSave: () => { this.sync(); save(); },
      onNewGame: () => { this.skipSave = true; clearSave(); this.scene.start('Creator'); },
    });
    bus.emit('money', game.money);
    bus.emit('clock', game.time);

    document.addEventListener('visibilitychange', this.onHide);
    window.addEventListener('pagehide', this.onHide);
    this.events.once('shutdown', () => {
      document.removeEventListener('visibilitychange', this.onHide);
      window.removeEventListener('pagehide', this.onHide);
      this.scale.off('resize', this.applyZoom, this);
      if (!this.skipSave) { this.sync(); save(); }
      this.hud.destroy();
      bus.emit('prompt', null);
    });

    if (!game.flags.introSeen) {
      game.flags.introSeen = true;
      this.time.delayedCall(700, () => bus.emit('toast', 'Day 1. $150, an old phone, and a worn backpack.'));
      this.time.delayedCall(4800, () => bus.emit('toast', '📱 New text: Ray’s Auto needs a hand. (Phone + jobs arrive in Milestone 7.)'));
    }
  }

  private applyZoom() {
    this.cameras.main.setZoom(Phaser.Math.Clamp(this.scale.width / 300, 1.1, 2.4));
  }

  private sync() { game.pos = { x: this.player.x, y: this.player.y }; }

  update(_t: number, delta: number) {
    const dt = Math.min(delta, 100) / 1000;
    this.acc += dt;
    while (this.acc >= STEP) { this.simulate(STEP); this.acc -= STEP; }
    this.render(dt);
  }

  // ------------------------------------------------------------ simulation (no rendering here)

  private simulate(dt: number) {
    let vx = this.hud.joystick.vec.x, vy = this.hud.joystick.vec.y;
    const c = this.cursors, k = this.wasd;
    if (c && k) {
      const kx = (c.right.isDown || k.D.isDown ? 1 : 0) - (c.left.isDown || k.A.isDown ? 1 : 0);
      const ky = (c.down.isDown || k.S.isDown ? 1 : 0) - (c.up.isDown || k.W.isDown ? 1 : 0);
      if (kx || ky) { const l = Math.hypot(kx, ky); vx = kx / l; vy = ky / l; }
    }
    this.pvx = vx * SPEED; this.pvy = vy * SPEED;
    this.moveAxis(this.pvx * dt, 0);
    this.moveAxis(0, this.pvy * dt);
    game.time += dt * GAME_MIN_PER_SEC;
  }

  private moveAxis(dx: number, dy: number) {
    const nx = this.player.x + dx, ny = this.player.y + dy;
    const w = this.world;
    if (nx < 24 || nx > w.width - 24 || ny < 60 || ny > w.height - 6) return;
    const bx = nx - FEET_W / 2, by = ny - FEET_H;
    for (const r of w.colliders) {
      if (bx < r.x + r.w && bx + FEET_W > r.x && by < r.y + r.h && by + FEET_H > r.y) return;
    }
    this.player.x = nx; this.player.y = ny;
  }

  // ------------------------------------------------------------ presentation

  private render(dt: number) {
    this.player.tick(dt, this.pvx, this.pvy);
    this.player.setDepth(this.player.y);
    for (const wd of this.wanderers) wd.update(dt);

    this.uiT += dt; this.saveT += dt;
    if (this.uiT >= 0.25) {
      this.uiT = 0;
      const d = darkness(game.time);
      this.overlay.setFillStyle(tintFor(d), 1);
      for (const g of this.glows) g.o.setAlpha(d * g.max);
      bus.emit('clock', game.time);
      this.updatePrompt();
    }
    if (this.saveT >= 10) { this.saveT = 0; this.sync(); save(); }
  }

  private updatePrompt() {
    const px = this.player.x, py = this.player.y;
    const door = this.world.doors.find((d) => Math.abs(px - d.x) < 38 && py >= d.y && py <= d.y + 54);
    const id = door ? door.id : null;
    if (id === this.promptId) return;
    this.promptId = id;
    bus.emit('prompt', door ? { id: door.id, label: door.label, run: () => bus.emit('toast', door.message) } : null);
  }
}
