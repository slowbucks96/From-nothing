import Phaser from 'phaser';
import { drawGround } from '../art/ground';
import { BuildingDef, Rect, SignDef, drawBuilding } from '../art/buildings';
import { bakeProps } from '../art/props';
import { makeRng, INK } from '../art/draw';
import { P } from '../art/palette';

export type { Rect };

export interface DoorDef { id: string; x: number; y: number; label: string; message: string }
export interface WorldDef {
  width: number;
  height: number;
  colliders: Rect[];
  doors: DoorDef[];
  lights: Rect[];
  glows: { x: number; y: number; r: number }[];
  wanderZones: Rect[];
}

const W = 1000, H = 1500;

const BUILDINGS: BuildingDef[] = [
  { id: 'apt', kind: 'apt', name: 'EASTSIDE APTS', x: 20, y: 110, w: 310, h: 320, wall: P.rose, roof: P.roofTeal, trim: 0x3d6fd9, doorX: 150, cols: 4 },
  { id: 'store', kind: 'store', name: 'QUICK STOP', x: 330, y: 200, w: 270, h: 230, wall: P.cream, roof: P.roofRed, trim: 0x4caf6a, doorX: 465, cols: 0 },
  { id: 'house1', kind: 'house', name: '', x: 600, y: 150, w: 190, h: 280, wall: P.mustard, roof: P.roofPurple, trim: 0xd94a3a, doorX: 695, cols: 2 },
  { id: 'house2', kind: 'house', name: '', x: 790, y: 190, w: 190, h: 240, wall: P.sky, roof: P.roofOcher, trim: 0xf0a33a, doorX: 885, cols: 2 },
  { id: 'shop', kind: 'shop', name: "RAY'S AUTO", x: 20, y: 640, w: 340, h: 270, wall: P.slate, roof: P.roofSlate, trim: 0xd94a3a, doorX: 290, cols: 3 },
  { id: 'res1', kind: 'house', name: '', x: 480, y: 1130, w: 240, h: 280, wall: P.sage, roof: P.roofTeal, trim: 0x8a5ad9, doorX: 600, cols: 3 },
  { id: 'res2', kind: 'house', name: '', x: 740, y: 1160, w: 240, h: 250, wall: P.rose, roof: P.roofRed, trim: 0x2fa7b8, doorX: 860, cols: 3 },
];

const DOORS: DoorDef[] = [
  { id: 'apt', x: 150, y: 430, label: 'Enter Apartment', message: 'Your apartment interior is Milestone 4. Not built yet.' },
  { id: 'store', x: 465, y: 430, label: 'Enter Quick Stop', message: 'The convenience store interior is Milestone 4. Not built yet.' },
  { id: 'shop', x: 290, y: 910, label: "Enter Ray's Auto", message: "Ray's Auto interior and the repair job are Milestones 4 and 7. Not built yet." },
];

interface PropDef { tex: string; x: number; y: number; collider?: [number, number] }
const PROPS: PropDef[] = [
  ...[[480, 740], [620, 700], [800, 735], [900, 880], [520, 885], [700, 870]].map(([x, y]) => ({ tex: 'tree', x, y, collider: [22, 14] as [number, number] })),
  { tex: 'bench', x: 560, y: 808, collider: [64, 14] },
  { tex: 'bench', x: 860, y: 808, collider: [64, 14] },
  ...[[90, 446], [400, 446], [720, 446], [960, 446], [140, 936], [520, 936], [900, 936]].map(([x, y]) => ({ tex: 'lamp', x, y, collider: [8, 8] as [number, number] })),
  { tex: 'bin', x: 365, y: 448, collider: [26, 12] },
  { tex: 'bin', x: 870, y: 448, collider: [26, 12] },
  { tex: 'vend', x: 560, y: 450, collider: [44, 14] },
  { tex: 'tires', x: 215, y: 936, collider: [44, 14] },
  { tex: 'crate', x: 262, y: 936, collider: [34, 14] },
  { tex: 'hoop', x: 70, y: 1275, collider: [10, 10] },
  { tex: 'hoop', x: 420, y: 1275, collider: [10, 10] },
];

export function buildEastside(scene: Phaser.Scene): WorldDef {
  const rng = makeRng(7);
  const lights: Rect[] = [];
  const signs: SignDef[] = [];

  // 1. Bake ground + buildings into one static texture (cheap to render on phones)
  const g = scene.make.graphics({ x: 0, y: 0 }, false);
  drawGround(g, rng, W, H);
  for (const b of BUILDINGS) drawBuilding(g, b, rng, lights, signs);
  g.generateTexture('eastside-ground', W, H);
  g.destroy();
  scene.add.image(0, 0, 'eastside-ground').setOrigin(0, 0).setDepth(0);

  // 2. Signs (text objects so they stay crisp)
  for (const s of signs) {
    scene.add.text(s.x, s.y, s.text, {
      fontFamily: 'Impact, "Arial Black", sans-serif', fontSize: `${s.size}px`, color: s.color,
      stroke: s.color === '#2b1b2f' ? '#f2c53a' : '#' + INK.toString(16).padStart(6, '0'), strokeThickness: s.color === '#2b1b2f' ? 0 : 4,
      resolution: 2,
    }).setOrigin(0.5).setDepth(1);
  }

  // 3. Depth-sorted props
  bakeProps(scene);
  const colliders: Rect[] = BUILDINGS.map((b) => ({ x: b.x - 4, y: b.y, w: b.w + 8, h: b.h }));
  const glows: WorldDef['glows'] = [];
  for (const p of PROPS) {
    scene.add.image(p.x, p.y, p.tex).setOrigin(0.5, 1).setDepth(p.y);
    if (p.collider) colliders.push({ x: p.x - p.collider[0] / 2, y: p.y - p.collider[1], w: p.collider[0], h: p.collider[1] });
    if (p.tex === 'lamp') glows.push({ x: p.x, y: p.y - 88, r: 44 });
  }

  // 4. Court fence colliders (gap at x 190-290 on top side)
  colliders.push(
    { x: 14, y: 1104, w: 180, h: 10 }, { x: 286, y: 1104, w: 190, h: 10 },
    { x: 14, y: 1104, w: 10, h: 308 }, { x: 466, y: 1104, w: 10, h: 308 },
    { x: 14, y: 1404, w: 462, h: 10 },
  );

  return {
    width: W, height: H, colliders, doors: DOORS, lights, glows,
    wanderZones: [
      { x: 30, y: 480, w: 940, h: 130 },
      { x: 30, y: 960, w: 940, h: 150 },
      { x: 430, y: 690, w: 520, h: 100 },
      { x: 30, y: 1430, w: 940, h: 50 },
    ],
  };
}
