import { game } from './state';
import { SaveData } from './types';
import { SAVE_VERSION } from './constants';

const KEY = 'from-nothing:save';

export function hasSave(): boolean { return loadSave() !== null; }

export function save(): boolean {
  try { localStorage.setItem(KEY, JSON.stringify(game.toSave())); return true; } catch { return false; }
}

export function loadSave(): SaveData | null {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const d = JSON.parse(raw) as SaveData;
    return d.version === SAVE_VERSION ? d : null; // add migrations here when the format changes
  } catch { return null; }
}

export function clearSave() { try { localStorage.removeItem(KEY); } catch { /* ignore */ } }
