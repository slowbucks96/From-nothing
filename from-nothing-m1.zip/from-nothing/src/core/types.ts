export interface Appearance {
  name: string;
  age: number; // 18-25
  skin: number;
  body: number;
  face: number;
  hairStyle: number;
  hairColor: number;
  facial: number;
  shirt: number;
  shirtColor: number;
  pants: number;
  pantsColor: number;
  shoes: number;
  shoeColor: number;
  accessory: number;
  backpack: number;
  backpackColor: number;
}

export interface Needs { hunger: number; energy: number; hygiene: number; happiness: number }
export interface Transaction { t: number; amount: number; reason: string; balance: number }

export interface SaveData {
  version: number;
  appearance: Appearance;
  money: number;
  needs: Needs;
  time: number;
  pos: { x: number; y: number };
  transactions: Transaction[];
  flags: Record<string, boolean>;
  savedAt: number;
}
