import { game } from './state';
import { bus } from './events';
import { Transaction } from './types';

/**
 * The ONLY place money changes. Every job payout, purchase, rent bill, etc. must go through here
 * so the transaction history is always truthful.
 */
function record(amount: number, reason: string) {
  game.transactions.push({ t: game.time, amount, reason, balance: game.money });
  if (game.transactions.length > 300) game.transactions.splice(0, game.transactions.length - 300);
  bus.emit('money', game.money);
}

export const economy = {
  get balance() { return game.money; },
  canAfford(amount: number) { return game.money >= amount; },
  earn(amount: number, reason: string): boolean {
    if (!(amount > 0)) return false;
    game.money += amount;
    record(amount, reason);
    return true;
  },
  spend(amount: number, reason: string): boolean {
    if (!(amount > 0) || game.money < amount) return false;
    game.money -= amount;
    record(-amount, reason);
    return true;
  },
  history(limit = 50): Transaction[] {
    return game.transactions.slice(-limit).reverse();
  },
};
