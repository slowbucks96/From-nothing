import { Appearance, Needs, SaveData, Transaction } from './types';
import { START_MINUTES } from './clock';
import { SAVE_VERSION, WORLD_SPAWN } from './constants';

/** The single source of truth for gameplay. Rendering reads from here; it never owns state. */
class GameState {
  appearance!: Appearance;
  money = 0;
  needs: Needs = { hunger: 80, energy: 80, hygiene: 80, happiness: 70 };
  time = START_MINUTES;
  pos = { ...WORLD_SPAWN };
  transactions: Transaction[] = [];
  flags: Record<string, boolean> = {};

  reset(appearance: Appearance) {
    this.appearance = { ...appearance };
    this.money = 0;
    this.needs = { hunger: 80, energy: 80, hygiene: 80, happiness: 70 };
    this.time = START_MINUTES;
    this.pos = { ...WORLD_SPAWN };
    this.transactions = [];
    this.flags = {};
  }

  applySave(d: SaveData) {
    this.appearance = d.appearance;
    this.money = d.money;
    this.needs = Object.assign({ hunger: 80, energy: 80, hygiene: 80, happiness: 70 }, d.needs);
    this.time = d.time;
    this.pos = d.pos;
    this.transactions = d.transactions ?? [];
    this.flags = d.flags ?? {};
  }

  toSave(): SaveData {
    return {
      version: SAVE_VERSION,
      appearance: this.appearance,
      money: this.money,
      needs: this.needs,
      time: this.time,
      pos: this.pos,
      transactions: this.transactions,
      flags: this.flags,
      savedAt: Date.now(),
    };
  }
}

export const game = new GameState();
