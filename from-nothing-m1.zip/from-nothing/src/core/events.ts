/** Tiny typed event bus. Game logic emits, UI listens. Keeps state and rendering separate. */
export class Emitter<E extends Record<string, any>> {
  private map = new Map<keyof E, Array<(p: any) => void>>();
  on<K extends keyof E>(e: K, fn: (p: E[K]) => void): () => void {
    const list = this.map.get(e) ?? [];
    list.push(fn);
    this.map.set(e, list);
    return () => this.map.set(e, (this.map.get(e) ?? []).filter((f) => f !== fn));
  }
  emit<K extends keyof E>(e: K, payload: E[K]): void {
    (this.map.get(e) ?? []).forEach((f) => f(payload));
  }
}

export interface Prompt { id: string; label: string; run: () => void }
export interface GameEvents {
  money: number;
  clock: number;
  toast: string;
  prompt: Prompt | null;
}
export const bus = new Emitter<GameEvents>();
