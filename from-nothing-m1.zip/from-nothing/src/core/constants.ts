export const SAVE_VERSION = 1;
export const STARTING_CASH = 150;
// In front of the apartment building door (Eastside)
export const WORLD_SPAWN = { x: 150, y: 476 };
