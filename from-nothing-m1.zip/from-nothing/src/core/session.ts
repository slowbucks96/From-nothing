import { Appearance } from './types';
import { game } from './state';
import { economy } from './economy';
import { loadSave, save } from './save';
import { STARTING_CASH } from './constants';

export function startNewGame(look: Appearance) {
  game.reset(look);
  economy.earn(STARTING_CASH, 'Starting cash');
  save();
}

export function continueGame(): boolean {
  const d = loadSave();
  if (!d) return false;
  game.applySave(d);
  return true;
}
