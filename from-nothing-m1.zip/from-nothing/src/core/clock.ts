export const START_MINUTES = 7 * 60 + 30; // Day 1, 7:30 AM
export const GAME_MIN_PER_SEC = 1.2; // ~20 real minutes per in-game day

export const dayOf = (t: number) => Math.floor(t / 1440) + 1;

export function formatClock(t: number): string {
  const h = Math.floor(t / 60) % 24;
  const m = Math.floor(t % 60);
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `Day ${dayOf(t)} · ${h12}:${m.toString().padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`;
}

/** 0 = full daylight, 1 = deep night */
export function darkness(t: number): number {
  const h = (t / 60) % 24;
  if (h < 5) return 1;
  if (h < 8) return 1 - (h - 5) / 3;
  if (h < 17) return 0;
  if (h < 20) return (h - 17) / 3;
  return 1;
}

/** Multiply-blend tint colour for a given darkness. */
export function tintFor(d: number): number {
  const day = [255, 255, 255], dusk = [255, 190, 150], night = [66, 78, 146];
  const mix = (a: number[], b: number[], k: number) => a.map((v, i) => Math.round(v + (b[i] - v) * k));
  const c = d < 0.45 ? mix(day, dusk, d / 0.45) : mix(dusk, night, (d - 0.45) / 0.55);
  return (c[0] << 16) | (c[1] << 8) | c[2];
}
