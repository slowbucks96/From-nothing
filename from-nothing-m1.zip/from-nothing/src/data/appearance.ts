import { Appearance } from '../core/types';

export const OPTIONS = {
  body: ['Slim', 'Average', 'Broad'],
  face: ['Calm', 'Grin', 'Tired', 'Focused'],
  hairStyle: ['Buzz', 'Fade', 'Curly', 'Afro', 'Braids', 'Long', 'Bun'],
  facial: ['None', 'Stubble', 'Goatee', 'Beard'],
  shirt: ['Tee', 'Hoodie', 'Jacket', 'Tank'],
  pants: ['Jeans', 'Cargo', 'Shorts', 'Joggers'],
  shoes: ['Sneakers', 'Boots', 'High-tops'],
  accessory: ['None', 'Glasses', 'Cap', 'Beanie', 'Headphones'],
  backpack: ['Worn pack', 'Sling bag', 'Hiking pack'],
};

export const SKIN_TONES = [0xf8d2b0, 0xeab98c, 0xd29a6a, 0xb67a4b, 0x8d5a36, 0x5e3a24];
export const HAIR_COLORS = [0x1c1520, 0x4a2c1d, 0x8b5a2b, 0xd9a441, 0xc2492f, 0x6a6e7a, 0x3d7ad9, 0xd45aa0];
export const CLOTH_COLORS = [
  0xd94a3a, 0xf0a33a, 0xf2d64b, 0x4caf6a, 0x2fa7b8, 0x3d6fd9,
  0x4a6fa5, 0x8a5ad9, 0xe8e2d0, 0x3a3a4a, 0xd45aa0, 0x8a6a4a,
];

export const DEFAULT_APPEARANCE: Appearance = {
  name: '', age: 20, skin: 2, body: 1, face: 0,
  hairStyle: 1, hairColor: 0, facial: 0,
  shirt: 0, shirtColor: 8, pants: 0, pantsColor: 6,
  shoes: 0, shoeColor: 9, accessory: 0, backpack: 0, backpackColor: 11,
};

const base = (o: Partial<Appearance>): Appearance => ({ ...DEFAULT_APPEARANCE, name: 'NPC', ...o });

/** Ambient pedestrians (not the real NPC system yet - that is Milestone 6). */
export const WANDERER_LOOKS: Appearance[] = [
  base({ skin: 4, hairStyle: 3, hairColor: 0, shirt: 1, shirtColor: 1, pants: 3, pantsColor: 9, backpack: 1, backpackColor: 4 }),
  base({ skin: 1, hairStyle: 5, hairColor: 4, shirt: 2, shirtColor: 5, pants: 0, pantsColor: 6, accessory: 1, body: 0 }),
  base({ skin: 3, hairStyle: 4, hairColor: 1, facial: 3, shirt: 0, shirtColor: 3, pants: 1, pantsColor: 11, accessory: 3, body: 2 }),
  base({ skin: 0, hairStyle: 6, hairColor: 3, shirt: 3, shirtColor: 10, pants: 2, pantsColor: 6, shoes: 2, shoeColor: 0, face: 1 }),
];
