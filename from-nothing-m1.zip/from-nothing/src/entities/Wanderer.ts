import Phaser from 'phaser';
import { Appearance } from '../core/types';
import { CharacterRig } from './CharacterRig';

export interface Zone { x: number; y: number; w: number; h: number }

/** Ambient pedestrian that strolls inside a zone. Not an NPC (no dialogue/schedule yet). */
export class Wanderer {
  readonly rig: CharacterRig;
  private tx = 0; private ty = 0; private wait = 0;

  constructor(scene: Phaser.Scene, private zone: Zone, look: Appearance, private speed = 36) {
    this.rig = new CharacterRig(scene, 0, 0, look, 1);
    this.rig.x = zone.x + Math.random() * zone.w;
    this.rig.y = zone.y + Math.random() * zone.h;
    this.pick();
    this.rig.setDepth(this.rig.y);
  }

  private pick() {
    this.tx = this.zone.x + Math.random() * this.zone.w;
    this.ty = this.zone.y + Math.random() * this.zone.h;
  }

  update(dt: number) {
    if (this.wait > 0) { this.wait -= dt; this.rig.tick(dt, 0, 0); return; }
    const dx = this.tx - this.rig.x, dy = this.ty - this.rig.y, d = Math.hypot(dx, dy);
    if (d < 3) { this.wait = 1.5 + Math.random() * 3.5; this.pick(); this.rig.tick(dt, 0, 0); return; }
    const vx = (dx / d) * this.speed, vy = (dy / d) * this.speed;
    this.rig.x += vx * dt; this.rig.y += vy * dt;
    this.rig.tick(dt, vx, vy);
    this.rig.setDepth(this.rig.y);
  }
}
