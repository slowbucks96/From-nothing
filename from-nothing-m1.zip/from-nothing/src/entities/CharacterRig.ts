import Phaser from 'phaser';
import { Appearance } from '../core/types';
import { SKIN_TONES, HAIR_COLORS, CLOTH_COLORS } from '../data/appearance';
import { G, INK, box, oval, stroke, shade } from '../art/draw';

export type Facing = 'down' | 'up' | 'side';

/** Draw order, back to front. Every customization category owns a layer. */
const LAYERS = [
  'shadow', 'hairBack', 'packBack', 'body', 'pants', 'shirt',
  'packFront', 'shoes', 'facial', 'face', 'hairFront', 'accessory',
] as const;
type LayerName = (typeof LAYERS)[number];

interface Leg { x: number; w: number; raise: number }

/**
 * Layered, procedurally drawn character (feet at local 0,0, ~62px tall, chunky 3-head proportions).
 * Temporary art: when real sprite sheets exist, replace the draw methods with sprite layers
 * that use the same 12 layer names and the same Appearance data. Nothing else needs to change.
 */
export class CharacterRig extends Phaser.GameObjects.Container {
  private g = {} as Record<LayerName, G>;
  private look: Appearance;
  private facing: Facing = 'down';
  private flip = 1;
  private phase = 0;
  private step = 4; // 0-3 walk frames, 4 idle
  private idleT = Math.random() * 6;
  private baseScale: number;
  private key = '';

  constructor(scene: Phaser.Scene, x: number, y: number, look: Appearance, scale = 1) {
    super(scene, x, y);
    this.look = look;
    this.baseScale = scale;
    for (const n of LAYERS) {
      const gr = scene.make.graphics({ x: 0, y: 0 }, false);
      this.g[n] = gr;
      this.add(gr);
    }
    scene.add.existing(this);
    this.setScale(scale);
    this.redraw();
  }

  setLook(look: Appearance) { this.look = look; this.key = ''; this.redraw(); }
  setBaseScale(s: number) { this.baseScale = s; }
  face(f: Facing, flip = 1) { this.facing = f; this.flip = flip; }

  /** Call every frame with the velocity the character is actually moving at. */
  tick(dt: number, vx: number, vy: number) {
    const moving = Math.abs(vx) + Math.abs(vy) > 1;
    if (moving) {
      if (Math.abs(vy) > Math.abs(vx)) this.facing = vy < 0 ? 'up' : 'down';
      else { this.facing = 'side'; this.flip = vx < 0 ? -1 : 1; }
      this.phase += dt * 9;
      this.step = Math.floor(this.phase) % 4;
    } else {
      this.phase = 0;
      this.step = 4;
    }
    this.idleT += dt;
    const breathe = moving ? 1 : 1 + Math.sin(this.idleT * 3) * 0.012;
    this.setScale(this.baseScale * this.flip, this.baseScale * breathe);
    const k = `${this.facing}${this.step}`;
    if (k !== this.key) { this.key = k; this.redraw(); }
  }

  // ---------------------------------------------------------------- drawing

  private legs(f: Facing, bw: number, sw: number): Leg[] {
    if (f === 'side') return [-1, 1].map((k) => ({ x: -5 + k * sw * 5, w: 10, raise: k * sw > 0 ? 3 : 0 }));
    const lw = Math.round(bw / 2) - 3;
    return [{ x: -lw - 1, w: lw, raise: sw > 0 ? 3 : 0 }, { x: 1, w: lw, raise: sw < 0 ? 3 : 0 }];
  }

  private redraw() {
    const L = this.look, f = this.facing, s = this.step;
    for (const n of LAYERS) this.g[n].clear();
    const bob = s === 1 || s === 3 ? -2 : 0;
    for (const n of LAYERS) this.g[n].y = n === 'shadow' ? 0 : bob;

    const skin = SKIN_TONES[L.skin], hair = HAIR_COLORS[L.hairColor];
    const bw = [22, 26, 31][L.body];
    const sw = s < 4 ? [0, 1, 0, -1][s] : 0;
    const legs = this.legs(f, bw, sw);

    this.g.shadow.fillStyle(0x000000, 0.28);
    this.g.shadow.fillEllipse(0, 1, 42, 12);

    this.drawHairBack(this.g.hairBack, f, L.hairStyle, hair);
    this.drawPack(this.g.packBack, this.g.packFront, f, L, bw);
    this.drawBody(this.g.body, f, skin, bw, sw);
    this.drawPants(this.g.pants, f, L, CLOTH_COLORS[L.pantsColor], bw, legs, skin);
    this.drawShirt(this.g.shirt, f, L, CLOTH_COLORS[L.shirtColor], bw, sw, skin);
    this.drawShoes(this.g.shoes, L, CLOTH_COLORS[L.shoeColor], legs, f);
    this.drawFacial(this.g.facial, f, L.facial, hair);
    this.drawFace(this.g.face, f, L.face, skin);
    this.drawHairFront(this.g.hairFront, f, L.hairStyle, hair);
    this.drawAccessory(this.g.accessory, f, L.accessory);
  }

  private drawBody(g: G, f: Facing, skin: number, bw: number, sw: number) {
    if (f !== 'side') {
      box(g, -bw / 2 - 6, -29 + sw * 2, 7, 17, 3, skin);
      box(g, bw / 2 - 1, -29 - sw * 2, 7, 17, 3, skin);
    }
    box(g, -5, -33, 10, 6, 2, skin);
    oval(g, 0, -45, 16, 15, skin);
    if (f === 'side') {
      oval(g, -4, -44, 3.5, 4, skin, 1, 2.5);
      oval(g, 15.5, -42, 3, 3, skin, 1, 2.5);
    } else {
      oval(g, -16, -44, 3.5, 4.5, skin, 1, 2.5);
      oval(g, 16, -44, 3.5, 4.5, skin, 1, 2.5);
    }
  }

  private drawPants(g: G, f: Facing, L: Appearance, col: number, bw: number, legs: Leg[], skin: number) {
    for (const lg of legs) {
      const top = -12, h = 12 - lg.raise;
      if (L.pants === 2) {
        box(g, lg.x + 1, top + 6, lg.w - 2, h - 6, 2, skin);
        box(g, lg.x, top, lg.w, 9, 2, col);
      } else {
        box(g, lg.x, top, lg.w, h, 2, col);
        if (L.pants === 1 && f !== 'up') box(g, lg.x + 1.5, top + 4, lg.w - 3, 5, 1, shade(col, 1.25), 1, 2);
        if (L.pants === 3) { g.fillStyle(shade(col, 0.65), 1); g.fillRect(lg.x + 1, top + h - 3, lg.w - 2, 3); }
      }
    }
    const hw = f === 'side' ? bw - 8 : bw;
    box(g, -hw / 2 + 1, -17, hw - 2, 7, 3, col);
  }

  private drawShirt(g: G, f: Facing, L: Appearance, col: number, bw: number, sw: number, skin: number) {
    const side = f === 'side';
    const tw = side ? bw - 8 : bw, tx = -tw / 2;
    const sl = [9, 15, 15, 0][L.shirt]; // sleeve length
    if (!side && sl > 0) {
      box(g, -bw / 2 - 6, -29 + sw * 2, 7, sl, 3, col);
      box(g, bw / 2 - 1, -29 - sw * 2, 7, sl, 3, col);
    }
    box(g, tx, -30, tw, 18, 5, col);
    g.fillStyle(0x000000, 0.12);
    g.fillRect(tx + 2, -18, tw - 4, 5);
    if (L.shirt === 0 && f === 'down') { oval(g, 0, -29, 6, 3, skin, 1, 2.5); g.fillStyle(shade(col, 1.25), 1); g.fillCircle(-tw / 4, -22, 2.5); }
    if (L.shirt === 1) {
      oval(g, 0, -29, 8, 4, shade(col, 0.8), 1, 2.5);
      if (f === 'down') {
        box(g, -8, -20, 16, 7, 3, shade(col, 0.9), 1, 2.5);
        stroke(g, -3, -27, -3, -22, 1.5, 0xffffff); stroke(g, 3, -27, 3, -22, 1.5, 0xffffff);
      }
    }
    if (L.shirt === 2) {
      oval(g, 0, -29, 7, 3.5, shade(col, 0.8), 1, 2.5);
      stroke(g, 0, -27, 0, -13, 2.5, INK);
      g.fillStyle(shade(col, 1.3), 1); g.fillRect(tx + 2, -15, tw - 4, 3);
    }
    if (L.shirt === 3 && f === 'down') oval(g, 0, -29, 7, 5, skin, 1, 2.5);
    if (side) { // near arm drawn over the torso
      const ax = -3.5 + sw * 5;
      box(g, ax, -29, 8, 17, 3, skin);
      if (sl > 0) box(g, ax, -29, 8, sl, 3, col);
    }
  }

  private drawShoes(g: G, L: Appearance, col: number, legs: Leg[], f: Facing) {
    for (const lg of legs) {
      const top = -6 - lg.raise;
      const fx = lg.x - 1, fw = lg.w + 2 + (f === 'side' ? 3 : 0);
      if (L.shoes === 1) box(g, lg.x, top - 6, lg.w, 8, 2, col);
      if (L.shoes === 2) box(g, lg.x, top - 5, lg.w, 7, 2, 0xf4f4f4);
      box(g, fx, top, fw, 7, 3, L.shoes === 1 ? shade(col, 0.85) : col);
      g.fillStyle(L.shoes === 1 ? 0x2b2020 : 0xf4f4f4, 1);
      g.fillRect(fx + 1.5, top + 5, fw - 3, 2);
    }
  }

  private drawPack(gb: G, gf: G, f: Facing, L: Appearance, bw: number) {
    const col = CLOTH_COLORS[L.backpackColor], dark = shade(col, 0.65), st = L.backpack;
    const tall = st === 2 ? 30 : 24;
    if (f === 'up') {
      if (st === 1) { box(gf, -bw / 2 + 2, -28, bw - 4, 14, 4, col); return; }
      box(gf, -bw / 2 - 2, st === 2 ? -38 : -33, bw + 4, tall, 6, col);
      box(gf, -bw / 2 + 3, -22, bw - 6, 9, 3, dark, 1, 2.5);
      return;
    }
    if (f === 'down') {
      if (st === 1) {
        stroke(gf, -bw / 2 + 3, -29, bw / 2 - 2, -14, 7, INK);
        stroke(gf, -bw / 2 + 3, -29, bw / 2 - 2, -14, 4, col);
        box(gf, bw / 2 - 7, -22, 12, 11, 3, col);
      } else {
        box(gb, -bw / 2 - 4, st === 2 ? -38 : -34, bw + 8, tall, 6, col);
        for (const sx of [-1, 1]) box(gf, sx * (bw / 2 - 6) - 2, -30, 4, 15, 1, dark, 1, 2.5);
      }
      return;
    }
    if (st === 1) { box(gb, -(bw - 8) / 2 - 7, -24, 10, 11, 3, col); return; }
    box(gb, -(bw - 8) / 2 - 9, st === 2 ? -38 : -33, 12, tall, 5, col);
    box(gf, -3, -30, 4, 15, 1, dark, 1, 2.5);
  }

  private drawHairBack(g: G, f: Facing, style: number, col: number) {
    const side = f === 'side';
    if (style === 3) oval(g, side ? -3 : 0, -52, side ? 20 : 23, 21, col);
    if (style === 5) {
      if (f === 'down') box(g, -19, -56, 38, 36, 10, col);
      if (side) box(g, -21, -56, 17, 36, 8, col);
    }
    if (style === 4) {
      if (f === 'down') for (const x of [-16, 16]) box(g, x - 3, -52, 6, 28, 3, col);
      if (side) box(g, -19, -52, 6, 28, 3, col);
    }
  }

  private drawHairFront(g: G, f: Facing, style: number, col: number) {
    if (f === 'up') {
      oval(g, 0, -46, 17.5, 16.5, col);
      if (style === 5) box(g, -17, -50, 34, 28, 8, col);
      if (style === 4) for (const x of [-12, 0, 12]) box(g, x - 3, -34, 6, 14, 3, col);
      if (style === 6) oval(g, 0, -67, 7.5, 7.5, col);
      return;
    }
    const side = f === 'side', ox = side ? -3 : 0;
    if (style === 2) for (const [x, y, r] of [[-11, -60, 6.5], [-3, -65, 7.5], [6, -65, 7.5], [13, -59, 6.5]]) oval(g, x + ox, y, r, r, col);
    if (style === 6) oval(g, side ? -7 : 0, -69, 7.5, 7.5, col);
    const capH = style === 0 ? 5 : style === 1 ? 6 : 7;
    oval(g, ox, -63 + capH, 17.5, capH, col);
    if (style === 1) { g.lineStyle(2, shade(col, 0.6), 1); for (let i = -2; i <= 2; i++) g.lineBetween(ox + i * 5, -62, ox + i * 5 + 1, -58); }
    if (!side && style !== 0 && style !== 3) for (const x of [-17, 13]) box(g, x, -53, 4, 8, 1, col, 1, 2.5);
  }

  private drawFace(g: G, f: Facing, style: number, skin: number) {
    if (f === 'up') return;
    const side = f === 'side';
    const eyes = side ? [8] : [-7, 7];
    for (const ex of eyes) {
      oval(g, ex, -42, 4.2, 5, 0xffffff, 1, 2);
      g.fillStyle(INK, 1); g.fillCircle(ex + (side ? 1.5 : 0), -41, 2.4);
      g.fillStyle(0xffffff, 1); g.fillCircle(ex + (side ? 2.3 : 0.8), -42.6, 0.9);
      if (style === 2) { g.fillStyle(skin, 1); g.fillRect(ex - 5, -47.5, 10, 5); stroke(g, ex - 5, -42.5, ex + 5, -42.5, 2.5, INK); }
      let a = [ex - 4, -49.5, ex + 4, -49.5];
      if (style === 1) a = [ex - 4, -50, ex + 4, -51.5];
      if (style === 2) a = [ex - 4, -49, ex + 4, -50];
      if (style === 3) a = side ? [ex - 4, -51, ex + 4, -49] : ex < 0 ? [ex - 4, -52, ex + 4, -49] : [ex - 4, -49, ex + 4, -52];
      stroke(g, a[0], a[1], a[2], a[3], 3, INK);
    }
    const mx = side ? 12 : 0;
    g.lineStyle(3, INK, 1);
    if (style === 1) { g.beginPath(); g.arc(mx, -37, 6, 0.15 * Math.PI, 0.85 * Math.PI, false); g.strokePath(); g.fillStyle(0xff7a7a, 0.35); if (!side) { g.fillEllipse(-12, -37, 7, 4); g.fillEllipse(12, -37, 7, 4); } }
    else if (style === 2) { g.beginPath(); g.arc(mx, -30, 5, 1.2 * Math.PI, 1.8 * Math.PI, false); g.strokePath(); }
    else if (style === 3) g.lineBetween(mx - 4, -34, mx + 4, -34);
    else g.lineBetween(mx - 3, -34, mx + 3, -34);
  }

  private drawFacial(g: G, f: Facing, style: number, col: number) {
    if (f === 'up' || style === 0) return;
    const side = f === 'side', cx = side ? 6 : 0, rx = side ? 10 : 13.5;
    if (style === 1) { g.fillStyle(col, 0.4); g.fillEllipse(cx, -37, rx * 2, 16); }
    if (style === 2) { oval(g, cx + (side ? 4 : 0), -29.5, 5, 5, col); if (!side) box(g, -6, -37, 12, 4, 2, col); }
    if (style === 3) oval(g, cx, -34, rx, 10.5, col);
  }

  private drawAccessory(g: G, f: Facing, id: number) {
    const side = f === 'side';
    if (id === 1 && f !== 'up') {
      g.fillStyle(0xbfe8ff, 0.35); g.lineStyle(3, INK, 1);
      for (const ex of side ? [8] : [-7, 7]) { g.fillCircle(ex, -42, 6.5); g.strokeCircle(ex, -42, 6.5); }
      if (!side) g.lineBetween(-1, -43, 1, -43); else g.lineBetween(2, -43, -12, -45);
    }
    if (id === 2) {
      const red = 0xd94a3a;
      oval(g, 0, -57, 18.5, 11, red);
      if (f === 'down') box(g, -19, -52, 38, 6, 3, shade(red, 0.8));
      if (side) box(g, 8, -53, 21, 5, 2, shade(red, 0.8));
    }
    if (id === 3) {
      const teal = 0x2fa7b8;
      oval(g, 0, -57, 18, 12, teal);
      box(g, -18, -52, 36, 8, 3, shade(teal, 0.8));
      oval(g, 0, -69, 4, 4, 0xf4f4f4, 1, 2.5);
    }
    if (id === 4) {
      g.beginPath(); g.lineStyle(6, INK, 1); g.arc(0, -48, 19, Math.PI, Math.PI * 2, false); g.strokePath();
      g.beginPath(); g.lineStyle(3, 0x666680, 1); g.arc(0, -48, 19, Math.PI, Math.PI * 2, false); g.strokePath();
      if (side) oval(g, -1, -44, 5, 8, 0x39394a);
      else for (const x of [-18, 18]) oval(g, x, -44, 5, 8, 0x39394a);
    }
  }
}
