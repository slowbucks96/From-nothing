import { G, INK, box, oval, pipe, stroke, shade } from './draw';
import { P } from './palette';

type Rng = () => number;
export interface Rect { x: number; y: number; w: number; h: number }
export interface SignDef { x: number; y: number; text: string; size: number; color: string }

export interface BuildingDef {
  id: string;
  kind: 'apt' | 'store' | 'shop' | 'house';
  name: string;
  x: number; y: number; w: number; h: number;
  wall: number; roof: number; trim: number;
  doorX: number;
  cols: number;
}

const ROOF = 46;

/** Angled top-down building: roof strip on top, illustrated facade below. All shapes inked. */
export function drawBuilding(g: G, b: BuildingDef, rng: Rng, lights: Rect[], signs: SignDef[]) {
  const bottom = b.y + b.h, fy = b.y + ROOF, fh = b.h - ROOF;

  // sidewalk + cast shadow
  g.fillStyle(P.sidewalk, 1); g.fillRect(b.x - 4, bottom, b.w + 8, 16);
  stroke(g, b.x - 4, bottom + 16, b.x + b.w + 4, bottom + 16, 3, INK);
  g.fillStyle(0x1b1530, 0.28); g.fillRect(b.x + 6, bottom + 16, b.w + 10, 14);

  // facade
  box(g, b.x, fy, b.w, fh, 0, b.wall);
  g.lineStyle(1, 0x000000, 0.09);
  for (let yy = fy + 14; yy < bottom - 4; yy += b.kind === 'apt' ? 12 : 16) g.lineBetween(b.x + 2, yy, b.x + b.w - 2, yy);
  if (b.kind === 'apt') for (let i = 0; i < 90; i++) { const bx = b.x + 4 + rng() * (b.w - 8), by = fy + 6 + rng() * (fh - 12); g.lineBetween(bx, by, bx, by + 9); }
  g.fillStyle(0x000000, 0.1); g.fillRect(b.x + 2, bottom - 26, b.w - 4, 24);

  // roof
  box(g, b.x - 8, b.y, b.w + 16, ROOF, 4, b.roof);
  g.fillStyle(0xffffff, 0.18); g.fillRect(b.x - 4, b.y + 5, b.w + 8, 9);
  g.fillStyle(0x000000, 0.25); g.fillRect(b.x - 6, b.y + ROOF - 9, b.w + 12, 7);
  const acx = b.x + 16 + rng() * (b.w - 90);
  box(g, acx, b.y + 12, 42, 26, 3, 0xcdbfae);
  g.lineStyle(2, INK, 0.7); for (let i = 0; i < 4; i++) g.lineBetween(acx + 6, b.y + 18 + i * 5, acx + 36, b.y + 18 + i * 5);
  if (b.kind === 'apt') { box(g, b.x + b.w - 70, b.y + 8, 32, 30, 4, 0x8a8f9a); oval(g, b.x + b.w - 54, b.y + 6, 18, 6, 0xa5aab5); }
  // pipes running down the facade
  pipe(g, b.x + b.w - 16, b.y + ROOF - 4, b.x + b.w - 16, bottom - 30, 4, 0xe879a8);
  pipe(g, b.x + 14, b.y + ROOF - 4, b.x + 14, bottom - 56, 4, 0xe0b04a);

  // windows (not on stores - they get display windows)
  if (b.kind !== 'store') {
    const rows = Math.max(1, Math.floor((fh - 96) / 62));
    const sp = b.w / b.cols;
    for (let r = 0; r < rows; r++) for (let c = 0; c < b.cols; c++) {
      const wx = b.x + sp * (c + 0.5) - 17, wy = fy + 16 + r * 62;
      if (b.kind === 'shop' && wy > fy + 40) continue;
      if (Math.abs(wx + 17 - b.doorX) < 34 && r === rows - 1 && fh < 150) continue;
      drawWindow(g, wx, wy, rng, lights);
    }
  }

  // door
  const dx = b.doorX;
  box(g, dx - 30, bottom - 6, 60, 10, 2, P.curb);
  box(g, dx - 20, bottom - 62, 40, 62, 4, b.trim);
  box(g, dx - 12, bottom - 54, 24, 26, 3, P.glass);
  g.fillStyle(0xffffff, 0.35); g.fillTriangle(dx - 10, bottom - 52, dx - 2, bottom - 52, dx - 10, bottom - 36);
  g.fillStyle(0xf2d64b, 1); g.fillCircle(dx + 12, bottom - 22, 2.5);

  if (b.kind === 'apt') {
    for (let i = 0; i < 3; i++) box(g, dx - 40 - i * 4, bottom + 4 + i * 4 - 4, 80 + i * 8, 5, 1, P.curb, 1, 2.5);
    box(g, b.x + 14, bottom - 40, 54, 30, 3, 0x6f86a8); // mailboxes
    for (let i = 0; i < 4; i++) box(g, b.x + 18 + i * 12, bottom - 36, 9, 10, 1, 0xc7d3e6, 1, 2);
    signs.push({ x: b.x + b.w / 2, y: fy + 10, text: b.name, size: 20, color: '#fff3d6' });
    box(g, b.x + b.w / 2 - 78, fy - 1, 156, 22, 4, 0x3a3350);
  }

  if (b.kind === 'store') {
    // display windows with shelves
    for (const wx of [b.x + 18, dx + 34]) {
      const ww = wx < dx ? dx - 34 - (b.x + 18) : b.x + b.w - 18 - (dx + 34);
      box(g, wx, bottom - 100, ww, 80, 4, P.glass);
      for (let s = 0; s < 3; s++) {
        stroke(g, wx + 4, bottom - 82 + s * 22, wx + ww - 4, bottom - 82 + s * 22, 3, INK);
        for (let i = 0; i < Math.floor(ww / 14); i++) { g.fillStyle([0xd94a3a, 0xf2d64b, 0x4caf6a, 0xf4f4f4][(i + s) % 4], 1); g.fillRect(wx + 6 + i * 14, bottom - 94 + s * 22, 9, 10); }
      }
      lights.push({ x: wx + 2, y: bottom - 98, w: ww - 4, h: 76 });
    }
    // striped awning
    const ax = b.x + 8, aw = b.w - 16, n = 12, sw = aw / n;
    for (let i = 0; i < n; i++) {
      const c = i % 2 ? 0xf3e7a9 : 0x7fb069;
      box(g, ax + i * sw, fy + 28, sw, 22, 0, c, 1, 2.5);
      oval(g, ax + i * sw + sw / 2, fy + 50, sw / 2, 6, c, 1, 2.5);
    }
    box(g, b.x + b.w / 2 - 72, fy - 2, 144, 28, 5, 0xf2c53a);
    signs.push({ x: b.x + b.w / 2, y: fy + 12, text: b.name, size: 22, color: '#2b1b2f' });
  }

  if (b.kind === 'shop') {
    box(g, b.x + 24, bottom - 102, 138, 102, 3, 0xb9c3cf);
    for (let i = 0; i < 8; i++) stroke(g, b.x + 26, bottom - 96 + i * 12, b.x + 160, bottom - 96 + i * 12, 2, 0x7c8796);
    g.fillStyle(0xf2c53a, 1); for (let i = 0; i < 9; i++) g.fillRect(b.x + 24 + i * 16, bottom - 112, 8, 10);
    box(g, b.x + b.w / 2 - 74, fy + 2, 148, 30, 5, 0xd94a3a);
    signs.push({ x: b.x + b.w / 2, y: fy + 17, text: b.name, size: 22, color: '#fff3d6' });
  }

  if (b.kind === 'house') {
    box(g, dx - 28, bottom - 82, 56, 14, 3, shade(b.trim, 1.2)); // little door awning
    stroke(g, b.x + 8, fy + 8, b.x + b.w - 8, fy + 20, 2, INK); // laundry line
    g.fillStyle(0xf2d64b, 1); g.fillRect(b.x + 30, fy + 10, 20, 16); g.fillStyle(0xd45aa0, 1); g.fillRect(b.x + 70, fy + 12, 16, 18);
  }
}

function drawWindow(g: G, wx: number, wy: number, rng: Rng, lights: Rect[]) {
  box(g, wx, wy, 34, 42, 3, P.glass);
  stroke(g, wx + 17, wy, wx + 17, wy + 42, 2.5, INK);
  stroke(g, wx, wy + 21, wx + 34, wy + 21, 2.5, INK);
  g.fillStyle(0xffffff, 0.3); g.fillTriangle(wx + 3, wy + 3, wx + 14, wy + 3, wx + 3, wy + 20);
  const roll = rng();
  if (roll < 0.3) { g.fillStyle([0xd94a3a, 0xf0a33a, 0xd45aa0][Math.floor(rng() * 3)], 1); g.fillRect(wx + 2, wy + 2, 30, 10); g.lineStyle(2, INK, 1); g.strokeRect(wx + 2, wy + 2, 30, 10); }
  else if (roll < 0.5) { box(g, wx - 3, wy + 42, 40, 6, 1, 0xcdbfae, 1, 2.5); oval(g, wx + 17, wy + 40, 8, 6, 0x4caf6a, 1, 2.5); }
  else if (roll < 0.6) { box(g, wx - 6, wy, 6, 42, 1, 0x4f9a9a, 1, 2.5); box(g, wx + 34, wy, 6, 42, 1, 0x4f9a9a, 1, 2.5); }
  if (rng() < 0.7) lights.push({ x: wx + 2, y: wy + 2, w: 30, h: 38 });
}
