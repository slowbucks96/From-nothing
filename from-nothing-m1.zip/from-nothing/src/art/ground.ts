import { G, INK, box, oval, pipe, stroke } from './draw';
import { P } from './palette';

type Rng = () => number;

function street(g: G, rng: Rng, x: number, y: number, w: number, h: number) {
  g.fillStyle(P.mortar, 1);
  g.fillRect(x, y, w, h);
  const rows = Math.ceil(h / 12);
  for (let r = 0; r < rows; r++) {
    const off = (r % 2) * 12;
    for (let bx = x - 24 + off; bx < x + w; bx += 24) {
      const roll = rng();
      const c = roll < 0.05 ? P.accents[Math.floor(rng() * P.accents.length)] : P.bricks[Math.floor(rng() * P.bricks.length)];
      g.fillStyle(c, 1);
      g.fillRect(Math.max(x, bx + 1), y + r * 12 + 1, Math.min(22, x + w - bx - 1), Math.min(10, h - r * 12 - 1));
    }
  }
  // worn paver patches
  for (let i = 0; i < 7; i++) {
    const px = x + rng() * (w - 90), py = y + 14 + rng() * (h - 50);
    g.fillStyle(P.accents[Math.floor(rng() * 3)], 0.55);
    g.fillRect(px, py, 36 + rng() * 54, 12 + rng() * 24);
  }
  // cracks, litter, manholes
  g.lineStyle(2, 0x8a4a2a, 0.5);
  for (let i = 0; i < 24; i++) { const cx = x + rng() * w, cy = y + 10 + rng() * (h - 20); g.lineBetween(cx, cy, cx + rng() * 22 - 8, cy + rng() * 10); }
  const litter = [0x6fb3a8, 0xf2d64b, 0xf4f4f4, 0xd45aa0];
  for (let i = 0; i < 26; i++) { g.fillStyle(litter[Math.floor(rng() * 4)], 1); g.fillRect(x + rng() * w, y + 8 + rng() * (h - 16), 4 + rng() * 5, 3 + rng() * 3); }
  for (let i = 0; i < 2; i++) oval(g, x + 140 + rng() * (w - 280), y + h * 0.5 + rng() * 20, 17, 9, 0x6a5a58, 1, 3);
}

function park(g: G, rng: Rng, x: number, y: number, w: number, h: number) {
  g.fillStyle(P.grass, 1); g.fillRect(x, y, w, h);
  for (let i = 0; i < 70; i++) {
    g.fillStyle([P.grassDark, P.grassLight][i % 2], 0.45);
    g.fillEllipse(x + rng() * w, y + rng() * h, 30 + rng() * 60, 14 + rng() * 26);
  }
  // paths
  g.fillStyle(P.path, 1);
  g.fillRect(x, y + 110, w, 34);
  g.fillRect(x + 220, y, 34, h);
  g.lineStyle(3, INK, 0.5);
  g.strokeRect(x, y + 110, w, 34);
  g.strokeRect(x + 220, y, 34, h);
  // flowers
  const fl = [0xf4f4f4, 0xf2d64b, 0xd45aa0, 0xd94a3a];
  for (let i = 0; i < 60; i++) { g.fillStyle(fl[i % 4], 1); g.fillCircle(x + 8 + rng() * (w - 16), y + 8 + rng() * (h - 16), 2.2); }
  // border curb
  g.lineStyle(4, INK, 1); g.strokeRect(x, y, w, h);
}

function court(g: G, x: number, y: number, w: number, h: number) {
  g.fillStyle(P.asphalt, 1); g.fillRect(x, y, w, h);
  g.fillStyle(0x000000, 0.07);
  for (let i = 0; i < 8; i++) g.fillRect(x + 20 + i * 52, y + 10, 24, h - 20);
  g.lineStyle(4, P.courtLine, 1);
  g.strokeRect(x + 28, y + 36, w - 56, h - 72);
  g.lineBetween(x + w / 2, y + 36, x + w / 2, y + h - 36);
  g.strokeCircle(x + w / 2, y + h / 2, 42);
  g.strokeRect(x + 28, y + h / 2 - 48, 78, 96);
  g.strokeRect(x + w - 106, y + h / 2 - 48, 78, 96);
  g.beginPath(); g.arc(x + 28, y + h / 2, 110, -Math.PI / 2, Math.PI / 2, false); g.strokePath();
  g.beginPath(); g.arc(x + w - 28, y + h / 2, 110, Math.PI / 2, (3 * Math.PI) / 2, false); g.strokePath();
  g.lineStyle(4, INK, 1); g.strokeRect(x, y, w, h);
}

/** Yellow rail with posts, as in the reference art. */
function rail(g: G, x1: number, y1: number, x2: number, y2: number) {
  pipe(g, x1, y1, x2, y2, 5, P.rail);
  const len = Math.hypot(x2 - x1, y2 - y1), n = Math.max(1, Math.floor(len / 46));
  for (let i = 0; i <= n; i++) {
    const px = x1 + ((x2 - x1) * i) / n, py = y1 + ((y2 - y1) * i) / n;
    box(g, px - 3, py - 1, 6, 12, 1, P.rail, 1, 2.5);
  }
}

export function drawGround(g: G, rng: Rng, W: number, H: number) {
  g.fillStyle(P.alley, 1); g.fillRect(0, 0, W, H);
  for (let i = 0; i < 40; i++) { g.fillStyle(0x000000, 0.08); g.fillEllipse(rng() * W, rng() * H, 80 + rng() * 120, 40 + rng() * 60); }
  street(g, rng, 0, 430, W, 210);
  street(g, rng, 0, 910, W, 250);
  street(g, rng, 0, 1410, W, 90);
  park(g, rng, 400, 640, 580, 270);
  court(g, 20, 1110, 450, 300);
  // court fencing (gap on the top side between x=190 and x=290)
  rail(g, 20, 1110, 190, 1110);
  rail(g, 290, 1110, 470, 1110);
  rail(g, 20, 1110, 20, 1405);
  rail(g, 470, 1110, 470, 1405);
  stroke(g, 20, 1408, 470, 1408, 6, INK);
}
