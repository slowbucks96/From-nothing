import Phaser from 'phaser';
import { G, box, oval, stroke, shade } from './draw';
import { P } from './palette';

function bake(scene: Phaser.Scene, key: string, w: number, h: number, draw: (g: G) => void) {
  if (scene.textures.exists(key)) return;
  const g = scene.make.graphics({ x: 0, y: 0 }, false);
  draw(g);
  g.generateTexture(key, w, h);
  g.destroy();
}

/** Props are baked once into textures (origin = bottom centre) and depth-sorted by the world scene. */
export function bakeProps(scene: Phaser.Scene) {
  bake(scene, 'tree', 100, 130, (g) => {
    box(g, 42, 84, 16, 44, 4, 0x8a5a3a);
    oval(g, 50, 54, 40, 36, 0x3f7a4a);
    oval(g, 32, 62, 22, 20, 0x4f8f55);
    oval(g, 68, 60, 24, 22, 0x4f8f55);
    oval(g, 50, 40, 28, 24, 0x6fae5a);
    g.fillStyle(0xffffff, 0.15); g.fillEllipse(42, 32, 22, 12);
  });
  bake(scene, 'lamp', 30, 100, (g) => {
    box(g, 12, 16, 6, 80, 2, 0x4b4a5a);
    box(g, 8, 90, 14, 8, 2, 0x4b4a5a);
    box(g, 4, 6, 22, 14, 4, 0xf2d64b);
  });
  bake(scene, 'bench', 80, 40, (g) => {
    box(g, 6, 2, 68, 10, 3, 0xb9773e);
    box(g, 4, 14, 72, 10, 3, 0xc98a4a);
    box(g, 10, 24, 6, 12, 1, 0x4b4a5a); box(g, 64, 24, 6, 12, 1, 0x4b4a5a);
  });
  bake(scene, 'crate', 44, 44, (g) => {
    box(g, 3, 3, 38, 38, 3, 0xb8743a);
    stroke(g, 6, 6, 38, 38, 3, 0x7a4a24); stroke(g, 38, 6, 6, 38, 3, 0x7a4a24);
  });
  bake(scene, 'bin', 34, 46, (g) => {
    box(g, 4, 12, 26, 32, 4, 0x5f7d8c);
    box(g, 2, 5, 30, 9, 3, 0x7d9aa8);
    for (let i = 0; i < 3; i++) stroke(g, 10 + i * 7, 18, 10 + i * 7, 40, 2, 0x3f5560);
  });
  bake(scene, 'vend', 54, 84, (g) => {
    box(g, 4, 4, 46, 78, 5, 0xd9463a);
    box(g, 10, 12, 34, 36, 3, P.glass);
    for (let i = 0; i < 6; i++) { g.fillStyle([0xf2d64b, 0x4caf6a, 0xf4f4f4][i % 3], 1); g.fillRect(14 + (i % 3) * 10, 17 + Math.floor(i / 3) * 14, 7, 10); }
    box(g, 16, 56, 22, 8, 2, shade(0xd9463a, 0.7), 1, 2.5);
  });
  bake(scene, 'hoop', 76, 124, (g) => {
    box(g, 34, 34, 8, 86, 2, 0x4b4a5a);
    box(g, 12, 8, 52, 34, 3, 0xf4f4f4);
    g.lineStyle(2.5, 0xd94a3a, 1); g.strokeRect(26, 20, 24, 16);
    oval(g, 38, 46, 13, 5, 0xf0a33a, 0, 3.5);
    g.lineStyle(1.5, 0xffffff, 1); for (let i = 0; i < 4; i++) g.lineBetween(27 + i * 8, 48, 31 + i * 6, 62);
  });
  bake(scene, 'tires', 56, 52, (g) => {
    oval(g, 28, 40, 22, 9, 0x2f2f3a); oval(g, 28, 30, 22, 9, 0x3a3a48); oval(g, 28, 20, 22, 9, 0x2f2f3a);
    oval(g, 28, 20, 9, 3.5, 0x6a6a7a, 1, 2);
  });
}
