import Phaser from 'phaser';

export type G = Phaser.GameObjects.Graphics;
/** Every outline in the game uses this ink colour (see docs/ART_SPEC.md). */
export const INK = 0x2b1b2f;

export function box(g: G, x: number, y: number, w: number, h: number, r: number, fill: number, alpha = 1, lw = 3) {
  const rr = Math.max(0, Math.min(r, w / 2, h / 2));
  g.fillStyle(fill, alpha);
  if (rr > 0) g.fillRoundedRect(x, y, w, h, rr); else g.fillRect(x, y, w, h);
  g.lineStyle(lw, INK, 1);
  if (rr > 0) g.strokeRoundedRect(x, y, w, h, rr); else g.strokeRect(x, y, w, h);
}

export function oval(g: G, cx: number, cy: number, rx: number, ry: number, fill: number, alpha = 1, lw = 3) {
  g.fillStyle(fill, alpha);
  g.fillEllipse(cx, cy, rx * 2, ry * 2);
  g.lineStyle(lw, INK, 1);
  g.strokeEllipse(cx, cy, rx * 2, ry * 2);
}

export function stroke(g: G, x1: number, y1: number, x2: number, y2: number, w: number, color: number) {
  g.lineStyle(w, color, 1);
  g.lineBetween(x1, y1, x2, y2);
}

/** Thick inked line with a colour core (pipes, rails, cables). */
export function pipe(g: G, x1: number, y1: number, x2: number, y2: number, w: number, color: number) {
  stroke(g, x1, y1, x2, y2, w + 4, INK);
  stroke(g, x1, y1, x2, y2, w, color);
}

export function shade(c: number, k: number): number {
  const r = Math.min(255, Math.round(((c >> 16) & 255) * k));
  const g = Math.min(255, Math.round(((c >> 8) & 255) * k));
  const b = Math.min(255, Math.round((c & 255) * k));
  return (r << 16) | (g << 8) | b;
}

export function makeRng(seed: number) {
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
