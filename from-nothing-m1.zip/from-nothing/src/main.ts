import Phaser from 'phaser';
import './style.css';
import { MenuScene } from './scenes/MenuScene';
import { CreatorScene } from './scenes/CreatorScene';
import { WorldScene } from './scenes/WorldScene';

// Block iOS pinch-zoom / double-tap zoom so the game owns touch input.
document.addEventListener('gesturestart', (e) => e.preventDefault());
document.addEventListener('dblclick', (e) => e.preventDefault());

new Phaser.Game({
  type: Phaser.AUTO,
  parent: 'game',
  backgroundColor: '#2a2440',
  scale: { mode: Phaser.Scale.RESIZE, width: window.innerWidth, height: window.innerHeight },
  render: { antialias: true, roundPixels: false },
  input: { activePointers: 3 },
  scene: [MenuScene, CreatorScene, WorldScene],
});
