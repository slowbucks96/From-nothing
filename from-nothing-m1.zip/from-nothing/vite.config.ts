import { defineConfig } from 'vite';

// base './' makes the build work from any sub-path (GitHub Pages, Netlify, etc.)
export default defineConfig({
  base: './',
  server: { host: true, port: 5173 },
  build: {
    chunkSizeWarningLimit: 2000,
    rollupOptions: { output: { manualChunks: { phaser: ['phaser'] } } },
  },
});
