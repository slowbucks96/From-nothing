# Art specification (applies to temporary AND final art)

Target: chunky, hand-inked, warm, layered, slightly more refined than the reference image.

- **Outline:** one ink colour `#2B1B2F`. 3px for characters/props/buildings at base scale. Never pure black.
- **Palette:** saturated warm base (orange brick, mustard, rose) with teal/purple/pink accents; shadows are cool purple (`#1B1530` at ~28% alpha), never grey.
- **Characters:** ~62px tall feet-to-chin at scale 1, head ≈ 1/2.2 of body height, big eyes. Camera zoom ≈ 1.3× on iPhone.
- **Facings:** down, up, side (left = mirrored right). Walk = 4 frames, idle = breathing.
- **Layer order (back→front):** shadow, hairBack, packBack, body, pants, shirt, packFront, shoes, facial, face, hairFront, accessory.
- **Buildings:** roof strip (46px) + facade, inked pipes/AC/awnings/signs, windows that glow at night.
- **Lighting:** day/night is a multiply tint plus additive window/lamp glows.

## Swapping in real art
`CharacterRig` is the only class that knows how characters are drawn. Replace its `draw*` methods with sprite layers
using the same layer names and the same `Appearance` data and nothing else in the game changes.
Building/prop art lives in `src/art/`. Replace baked textures there with your painted PNGs and keep the collider data in `src/maps/eastside.ts`.
