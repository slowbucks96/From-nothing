# Architecture

```
src/core/      GameState (single source of truth), economy (only way money changes), save, clock, event bus, session
src/data/      Content tables (appearance options now; items/NPCs/jobs later). Data, not logic.
src/art/       Procedural art (palette, ground, buildings, props). Swappable for real art.
src/entities/  CharacterRig (layered customizable character), Wanderer (ambient pedestrian)
src/maps/      One file per neighborhood. eastside.ts returns a WorldDef {colliders, doors, lights, zones}
src/scenes/    Phaser scenes: Menu, Creator, World (more: Interior, Minigame)
src/ui/        HTML/CSS overlays: HUD, joystick, creator panel (phone, inventory later)
```

Rules that keep it expandable:
1. Scenes render and read input. Rules/state live in `core/` and (soon) `systems/`.
2. Money changes only via `economy.earn/spend`.
3. Content is data (add a neighborhood = add a map file + register it; add an item = add a data row).
4. The save format is versioned (`SAVE_VERSION`) so old saves can be migrated.
5. UI talks to the game through `bus` events, never by reaching into scenes.
