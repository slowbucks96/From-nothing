# FROM NOTHING — Development Checklist

Legend: ✅ implemented in code · 🧪 implemented but NOT yet tested on a real device · ⏳ planned · ❌ not started

> Honest status: Milestone 1 was written without being able to run `npm install` / `vite` in the authoring
> environment, so everything below marked 🧪 has never been executed. Expect a few first-run bugs. Report them and they get fixed first.

## Milestone 1 — Foundation, character creator, first street
| Item | Status |
|---|---|
| Vite + TypeScript + Phaser 3 project, portrait/responsive scaling | 🧪 |
| Fixed-timestep simulation, state separated from rendering | 🧪 |
| Central `GameState` + event bus | 🧪 |
| Central `economy` service (earn/spend/history) — only place money changes | 🧪 |
| Local save/load (autosave every 10s, on tab hide, manual save) + New Game | 🧪 |
| Title menu (Continue / New Game) | 🧪 |
| Character creator: name, age 18–25, skin, build, hair style/color, facial hair, face, shirt, pants, shoes (+colors), accessory, backpack (+color) | 🧪 |
| Layered character rig (12 layers, 3 facings, 4-frame walk) — every option shows in-game | 🧪 |
| Live preview with turn + walk preview | 🧪 |
| Eastside street map: apartment, convenience store, auto shop, houses, park, basketball court, streets | 🧪 |
| 8-direction movement, touch joystick (DOM), keyboard for desktop | 🧪 |
| Building/prop collisions, camera follow + responsive zoom | 🧪 |
| Day/night cycle with window + street-lamp glow | 🧪 |
| HUD: cash, clock, pause menu | 🧪 |
| Door prompts (context button) | 🧪 — doors only show a "not built yet" message |
| Ambient pedestrians | 🧪 — decorative only, **not** NPCs |
| Add-to-Home-Screen (PWA-style meta, icon) | 🧪 |
| GitHub Pages auto-deploy workflow | 🧪 |

## Milestone 2 — Polish creator + art pipeline  ⏳
- Real sprite-sheet layer support (same 12 layer names), art pass on buildings/props
- Higher-DPR rendering, pinch/zoom buttons, more starter options

## Milestone 4 — Interiors ⏳  Apartment, convenience store, repair shop interiors; enter/exit doors
## Milestone 5 — Needs, inventory, purchases ⏳  Hunger/energy/hygiene/happiness, backpack, store buying, consumables, rent
## Milestone 6 — NPC system ⏳  5 NPCs, schedules, dialogue, relationships
## Milestone 7 — Phone + first job ⏳  Contacts, messages, wallet, map, jobs, character info; handyman repair minigame, skill XP
## Milestone 8 — First-day loop test ⏳  Sleep, apartment customization, full v0.1 success criteria pass

## Not implemented yet (do not assume these exist)
Interiors · needs · inventory · store purchases · NPC dialogue · smartphone · job/minigame · apartment customization · sleeping · rent
Wallet/transaction UI (the economy service and log exist; nothing displays history yet).

## Future (architecture accounts for these; v0.1 will not build them)
Vehicles, racing, swimming, basketball, fishing, careers, education, business, real estate, romance, families, crime, NPC finances, aging, legacy, other neighborhoods.
